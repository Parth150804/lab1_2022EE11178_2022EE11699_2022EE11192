# cop290-2402-C-RPM

[Problem Statement](https://docs.google.com/document/d/1Dm8R1kHqS2YvrGG9Ln6iv8XHfFTAXp1jI7Iq4iutvXM/edit?tab=t.0)
